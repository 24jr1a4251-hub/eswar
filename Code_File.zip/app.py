"""
app.py
------
Prompt-Driven Data Analysis Assistant
(IBM SkillsBuild Data Analytics Internship — Final Project)

A Streamlit app that lets a user ask plain-English questions about a
supermarket sales dataset. Every question passes through PromptIQ's
prompt-refinement layer before being sent to an LLM, which returns pandas
code that is executed safely against the dataset to produce a table
and/or chart.

Pipeline:
    raw question -> promptiq_refiner.refine_prompt() -> LLM call ->
    generated pandas code -> sandboxed execution -> result + chart

Run locally:
    streamlit run app.py

Requires an ANTHROPIC_API_KEY environment variable.
"""

import os
import re
import io
import contextlib

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import streamlit as st
import anthropic

from promptiq_refiner import refine_prompt

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------
MODEL_NAME = "claude-sonnet-4-6"
DATA_PATH = "sample_supermarket_sales.csv"

st.set_page_config(page_title="Prompt-Driven Data Analysis Assistant", layout="wide")


# --------------------------------------------------------------------------
# Data loading
# --------------------------------------------------------------------------
@st.cache_data
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    return df


def get_schema(df: pd.DataFrame) -> dict:
    return {col: str(dtype) for col, dtype in df.dtypes.items()}


# --------------------------------------------------------------------------
# LLM call
# --------------------------------------------------------------------------
def generate_pandas_code(refined_prompt: str) -> str:
    """Send the refined prompt to Claude and extract the returned code block."""
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    response = client.messages.create(
        model=MODEL_NAME,
        max_tokens=800,
        messages=[{"role": "user", "content": refined_prompt}],
    )
    text = "".join(block.text for block in response.content if block.type == "text")
    match = re.search(r"```(?:python)?\s*(.*?)```", text, re.DOTALL)
    return match.group(1).strip() if match else text.strip()


# --------------------------------------------------------------------------
# Safe(r) execution sandbox
# --------------------------------------------------------------------------
FORBIDDEN_PATTERNS = [
    r"\bimport\s+os\b", r"\bimport\s+sys\b", r"\bopen\s*\(",
    r"\beval\s*\(", r"\bexec\s*\(", r"__", r"\bsubprocess\b",
]


def is_code_safe(code: str) -> bool:
    return not any(re.search(pat, code) for pat in FORBIDDEN_PATTERNS)


def run_generated_code(code: str, df: pd.DataFrame):
    """Execute generated code in a restricted namespace and capture result/fig."""
    if not is_code_safe(code):
        raise ValueError("Generated code failed the safety check and was blocked.")

    local_ns = {"df": df, "pd": pd, "plt": plt}
    stdout_buffer = io.StringIO()
    with contextlib.redirect_stdout(stdout_buffer):
        exec(code, {"__builtins__": {}}, local_ns)  # noqa: S102 - restricted namespace

    result = local_ns.get("result")
    fig = local_ns.get("fig")
    return result, fig, stdout_buffer.getvalue()


# --------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------
st.title("🛒 Prompt-Driven Data Analysis Assistant")
st.caption(
    "Ask a plain-English question about the supermarket sales dataset. "
    "PromptIQ refines your question into a precise prompt before it reaches the model."
)

df = load_data(DATA_PATH)
schema = get_schema(df)

with st.expander("Preview dataset"):
    st.dataframe(df.head(20))
    st.write(f"{len(df)} rows · columns: {', '.join(df.columns)}")

question = st.text_input(
    "Your question",
    placeholder="e.g. Which branch had the best sales last month?",
)

show_refinement = st.checkbox("Show PromptIQ refinement step", value=True)

if st.button("Analyze") and question.strip():
    with st.spinner("Refining your prompt with PromptIQ..."):
        refined = refine_prompt(question, schema)

    if show_refinement:
        st.subheader("PromptIQ refinement")
        if refined.detected_ambiguities:
            st.write(
                "Ambiguous terms clarified: "
                + ", ".join(refined.detected_ambiguities)
            )
        else:
            st.write("No ambiguous terms detected — question was already precise.")
        with st.expander("Full refined prompt sent to the model"):
            st.code(refined.refined_prompt)

    if not os.environ.get("ANTHROPIC_API_KEY"):
        st.error("Set the ANTHROPIC_API_KEY environment variable to run live queries.")
    else:
        with st.spinner("Generating analysis..."):
            try:
                code = generate_pandas_code(refined.refined_prompt)
                st.subheader("Generated code")
                st.code(code, language="python")

                result, fig, stdout_text = run_generated_code(code, df)

                st.subheader("Result")
                if result is not None:
                    if isinstance(result, (pd.DataFrame, pd.Series)):
                        st.dataframe(result)
                    else:
                        st.write(result)
                if fig is not None:
                    st.pyplot(fig)
                if stdout_text:
                    st.text(stdout_text)
                if result is None and fig is None:
                    st.warning("The generated code did not produce a `result` or `fig` variable.")
            except Exception as exc:  # surfaced to the user, not swallowed
                st.error(f"Could not complete the analysis: {exc}")

st.divider()
st.caption(
    "Internship: IBM SkillsBuild Academic Internship — Data Analytics track. "
    "Prompt refinement adapted from the PromptIQ project."
)
