"""
promptiq_refiner.py
--------------------
Prompt-refinement layer for the Prompt-Driven Data Analysis Assistant.

This module reuses the core idea behind the PromptIQ project — "refining
input prompts to guide generative AI models in producing desired outputs"
— and applies it specifically to natural-language data-analysis questions.

Given a raw user question and the schema of the active dataset, it produces
a refined, unambiguous prompt that is far easier for an LLM to convert into
correct pandas code. Refinement happens in three stages:

  1. Schema grounding   - inject real column names / dtypes so the model
                           never has to guess a column name.
  2. Ambiguity repair    - detect vague terms (e.g. "recent", "best",
                           "top") and rewrite them into concrete,
                           measurable instructions.
  3. Intent structuring  - reshape the question into a fixed template the
                           downstream LLM has been prompted to expect,
                           which improves output consistency.

The module is intentionally dependency-free (no LLM call here) so it can
run fast and deterministically before the one LLM call that actually
generates code.
"""

from dataclasses import dataclass, field
from typing import Dict, List
import re


VAGUE_TERMS = {
    "recent": "within the most recent time period present in the dataset",
    "best": "highest by the most relevant numeric metric (e.g. total sales or profit)",
    "worst": "lowest by the most relevant numeric metric (e.g. total sales or profit)",
    "top": "ranked highest",
    "bottom": "ranked lowest",
    "a lot": "a comparatively high value",
    "good": "favorable relative to the dataset average",
    "bad": "unfavorable relative to the dataset average",
}

CHART_HINTS = {
    "trend": "line chart",
    "over time": "line chart",
    "compare": "bar chart",
    "comparison": "bar chart",
    "distribution": "histogram",
    "share": "pie chart",
    "breakdown": "bar chart",
    "correlation": "scatter plot",
}


@dataclass
class RefinedPrompt:
    original_question: str
    refined_prompt: str
    detected_ambiguities: List[str] = field(default_factory=list)
    suggested_chart_type: str = "bar chart"


def _detect_ambiguities(question: str) -> List[str]:
    q = question.lower()
    return [term for term in VAGUE_TERMS if re.search(rf"\b{re.escape(term)}\b", q)]


def _suggest_chart_type(question: str) -> str:
    q = question.lower()
    for keyword, chart in CHART_HINTS.items():
        if keyword in q:
            return chart
    return "bar chart"


def _rewrite_ambiguous_terms(question: str, ambiguities: List[str]) -> str:
    rewritten = question
    for term in ambiguities:
        rewritten = re.sub(
            rf"\b{re.escape(term)}\b",
            f"{term} ({VAGUE_TERMS[term]})",
            rewritten,
            flags=re.IGNORECASE,
        )
    return rewritten


def refine_prompt(question: str, schema: Dict[str, str]) -> RefinedPrompt:
    """
    Refine a raw natural-language data question into a structured prompt.

    Args:
        question: the user's raw question, e.g. "which branch did best?"
        schema:   dict of {column_name: dtype}, from the active DataFrame

    Returns:
        RefinedPrompt with the polished prompt text ready for the LLM.
    """
    ambiguities = _detect_ambiguities(question)
    clarified_question = _rewrite_ambiguous_terms(question, ambiguities)
    chart_type = _suggest_chart_type(question)

    schema_block = "\n".join(f"  - {col} ({dtype})" for col, dtype in schema.items())

    refined = f"""You are a data analysis assistant working with a pandas
DataFrame called `df`. It has the following columns:

{schema_block}

User question (clarified): {clarified_question}

Instructions:
- Return ONLY a single Python code block.
- The code must assign its final tabular result to a variable named `result`.
- If the question implies a chart, also create a matplotlib figure assigned
  to a variable named `fig`, using a {chart_type} unless the question
  clearly implies a different chart type.
- Never invent column names that are not listed above.
- Do not read or write any files; only operate on the in-memory `df`.
"""

    return RefinedPrompt(
        original_question=question,
        refined_prompt=refined.strip(),
        detected_ambiguities=ambiguities,
        suggested_chart_type=chart_type,
    )
